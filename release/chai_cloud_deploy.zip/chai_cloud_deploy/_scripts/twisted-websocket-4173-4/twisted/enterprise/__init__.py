# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.


"""
Twisted Enterprise: database support for Twisted services.
"""

__all__ = ['adbapi']
