# Tizen Splash Screen

Splash screens are unsupported on the Tizen platform.
