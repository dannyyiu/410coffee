/** Automatically generated file. DO NOT MODIFY */
package com.phonegap.chai_app;

public final class BuildConfig {
    public final static boolean DEBUG = false;
}