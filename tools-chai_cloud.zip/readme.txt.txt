=== chai cloud tools setup ===

Usage:
Just double-click on "SETUP.BAT"

Installs:
- Python 2.7.8
- easy_install
- sets up environmental variables
- Notepad++
- Github
